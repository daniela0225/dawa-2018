import React from 'react';

const home = () => (<div>
	<h1>Pagina de inicio de nuestro Blog</h1>
</div>);

export default home;